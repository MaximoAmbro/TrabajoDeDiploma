@echo off
setlocal

REM ==========================================================================
REM  EventAura - crea la base de datos de pruebas
REM
REM  Si tu instancia de SQL Server NO se llama SQLEXPRESS, cambia la linea
REM  de abajo. Para saber como se llama: menu Inicio, escribi "Servicios",
REM  y busca en la lista "SQL Server (ALGO)". ALGO es el nombre.
REM ==========================================================================

set INSTANCIA=.\SQLEXPRESS

cd /d "%~dp0"

echo.
echo   EventAura - creando la base BddEventAura
echo   Instancia: %INSTANCIA%
echo.

where sqlcmd >nul 2>&1
if errorlevel 1 goto sinsqlcmd

echo   [1/4] Borrando la base anterior si existe...
sqlcmd -S %INSTANCIA% -E -C -b -Q "IF DB_ID('BddEventAura') IS NOT NULL BEGIN ALTER DATABASE BddEventAura SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE BddEventAura; END; CREATE DATABASE BddEventAura;"
if errorlevel 1 goto sinconexion

echo   [2/4] Creando las tablas...
sqlcmd -S %INSTANCIA% -E -C -b -I -f 65001 -d BddEventAura -i "01-esquema.sql"
if errorlevel 1 goto error

echo   [3/4] Cargando los datos iniciales...
sqlcmd -S %INSTANCIA% -E -C -b -I -f 65001 -d BddEventAura -i "02-semilla.sql"
if errorlevel 1 goto error

echo   [4/4] Cargando los datos de los reportes (esto tarda un rato)...
sqlcmd -S %INSTANCIA% -E -C -b -I -f 65001 -d BddEventAura -i "03-datos-reporte.sql"
if errorlevel 1 goto error

echo.
echo   ====================================================================
echo    LISTO. Ya podes abrir Programa\Visual.exe
echo   ====================================================================
echo.
pause
exit /b 0

:sinsqlcmd
echo.
echo   ERROR: no se encontro el comando sqlcmd.
echo.
echo   Viene con SQL Server. Si instalaste SQL Server Express y no lo tenes,
echo   busca en Microsoft "SQL Server Command Line Utilities" e instalalo.
echo.
pause
exit /b 1

:sinconexion
echo.
echo   ERROR: no se pudo conectar a la instancia %INSTANCIA%
echo.
echo   Dos motivos posibles:
echo     1. Tu instancia se llama distinto. Abri este .bat con el Notepad y
echo        cambia la linea que dice  set INSTANCIA=.\SQLEXPRESS
echo     2. El servicio de SQL Server no esta corriendo. Menu Inicio,
echo        "Servicios", busca "SQL Server" y dale Iniciar.
echo.
pause
exit /b 1

:error
echo.
echo   ERROR al cargar los scripts. NO abras el programa todavia: la base
echo   quedo a medio crear.
echo.
echo   Mandale a Maximo el texto del error que aparece mas arriba.
echo.
pause
exit /b 1
